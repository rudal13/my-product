package carSales;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

 @RestController
 public class InsuranceController {
	 
	 @RequestMapping(value = "/insurance/insured/{carId}",
        method = RequestMethod.PUT,
        produces = "application/json;charset=UTF-8")

	 public Insurance salesRequest(@RequestParam Long id,
					       @RequestParam Integer salesAmount,
					       @RequestParam Integer drivingYear)
        throws Exception {
		 
		Integer insureRate = 0;
				
		if ( drivingYear > 20 ) { 
			insureRate = 1;
 		}
		else if ( drivingYear <= 20 & drivingYear > 10 ) { 
			insureRate = 2;
		}
		else {
			insureRate = 3;
		}
		Insurance insurance = new Insurance();
		insurance.setCarId(id);
		insurance.setSalesAmount(salesAmount);
		insurance.setInsureRate(insureRate);
		insurance.setInsureAmount(insureRate*salesAmount);
		
        System.out.println("##### insurance/insuredRequest  called #####");
        
        return insurance;
	 }
 }
