package carSales;

import javax.persistence.*;
import org.springframework.beans.BeanUtils;
import java.util.List;

@Entity
@Table(name="Insurance_table")
public class Insurance {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;
    private Long carId;
    private Integer salesAmount;
    private Integer insureRate;
    private Integer insureAmount;

    @PostPersist
    public void onPrePersist(){
        Insured insured = new Insured();
        BeanUtils.copyProperties(this, insured);
        insured.publishAfterCommit();


    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public Long getCarId() {
        return carId;
    }

    public void setCarId(Long carId) {
        this.carId = carId;
    }
    public Integer getSalesAmount() {
        return salesAmount;
    }

    public void setSalesAmount(Integer salesAmount) {
        this.salesAmount = salesAmount;
    }
    public Integer getInsureRate() {
        return insureRate;
    }

    public void setInsureRate(Integer insureRate) {
        this.insureRate = insureRate;
    }
    public Integer getInsureAmount() {
        return insureAmount;
    }

    public void setInsureAmount(Integer insureAmount) {
        this.insureAmount = insureAmount;
    }




}
