package carSales;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

 @RestController
 public class CarSalesController {

	 
	 @RequestMapping(value = "/carSales/{carId}",
        method = RequestMethod.PUT,
        produces = "application/json;charset=UTF-8")

	 public boolean buyRequest(@RequestParam Long reservationId,
					       @RequestParam String doctor,
					       @RequestParam String treatment,
					       @RequestParam String medicalOpinion)
        throws Exception {
        System.out.println("##### /medicalRecords/medicalRequest  called #####");
        
        return false;
	 }
 }
