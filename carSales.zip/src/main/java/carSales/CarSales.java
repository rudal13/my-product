package carSales;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PostUpdate;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.springframework.beans.BeanUtils;

@Entity
@Table(name="CarSales_table")
public class CarSales {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;
    private String carName;
    private Integer carYear;
    private Integer accidentCnt;
    private Integer buyAmount;
    private Integer salesAmount;
    private String status;
    private Integer drivingYear;

    @PrePersist
    public void onPrePersist(){
        Bought bought = new Bought();
        BeanUtils.copyProperties(this, bought);
        bought.publishAfterCommit();
    }

    @PostUpdate
    public void onPostUpdate(){
        Sold sold = new Sold();
        BeanUtils.copyProperties(this, sold);
        sold.publishAfterCommit();

        //Following code causes dependency to external APIs
        // it is NOT A GOOD PRACTICE. instead, Event-Policy mapping is recommended.

        carSales.external.Insurance insurance = new carSales.external.Insurance();
        // mappings goes here
        Application.applicationContext.getBean(carSales.external.InsuranceService.class)
            .insure(insurance);
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getCarName() {
        return carName;
    }

    public void setCarName(String carName) {
        this.carName = carName;
    }
    public Integer getCarYear() {
        return carYear;
    }

    public void setCarYear(Integer carYear) {
        this.carYear = carYear;
    }
    public Integer getAccidentCnt() {
        return accidentCnt;
    }

    public void setAccidentCnt(Integer accidentCnt) {
        this.accidentCnt = accidentCnt;
    }
    public Integer getBuyAmount() {
        return buyAmount;
    }

    public void setBuyAmount(Integer buyAmount) {
        this.buyAmount = buyAmount;
    }
    public Integer getSalesAmount() {
        return salesAmount;
    }

    public void setSalesAmount(Integer salesAmount) {
        this.salesAmount = salesAmount;
    }
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getDrivingYear() {
        return drivingYear;
    }
    public void setDrivingYear(Integer drivingYear) {
        this.drivingYear = drivingYear;
    }

}
