
package carSales.external;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(name="insurance", url="http://insurance:8080")
public interface InsuranceService {

    @RequestMapping(method= RequestMethod.POST, path="/insurances")
    public void insure(@RequestBody Insurance insurance);

}