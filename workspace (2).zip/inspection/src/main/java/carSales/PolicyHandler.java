package carSales;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeTypeUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import carSales.config.kafka.KafkaProcessor;

@Service
public class PolicyHandler{
	
	@Autowired
	InspectionRepository inspectionRepository;
    
    
    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverBought_Inspect(@Payload Bought bought){

    	Integer insureRate1 = 0;
    	Integer insureRate2 = 0;

        if ("Bought".equals(bought.getEventType())) {
            if(bought.isMe()){

            	Integer carYear = bought.getCarYear();
            	Integer carAccidentCnt = bought.getCarAccidentCnt();
            	
            	if (carYear < 10) {
            		insureRate1 = 1;
            	}
            	else if (carYear < 20) {
            		insureRate1 = 2;
            	}
            	else {
            		insureRate1 = 3;
            	}
            	if (carAccidentCnt < 2) {
            		insureRate1 = 1;
            	}
            	else if (carAccidentCnt < 5) {
            		insureRate1 = 2;
            	}
            	else {
            		insureRate1 = 3;
            	}
            	
            	Inspection inspection = new Inspection();
            	inspection.setCarId(bought.getId());
            	inspection.setStatus("inspected");
            	inspection.setInsureRate(insureRate1 + insureRate2);            	
            	inspectionRepository.save(inspection);
            	
            	Inspected inspected = new Inspected();
            	inspected.setCarId(inspection.getCarId());
            	inspected.setStatus(inspection.getStatus());
            	inspected.setInsureRate(inspection.getInsureRate());

            	ObjectMapper objectMapper = new ObjectMapper();
            	String json = null;

                try {
                    json = objectMapper.writeValueAsString(inspected);
                } catch (JsonProcessingException e) {
                     e.printStackTrace();
                }

                KafkaProcessor kafkaProcessor = Application.applicationContext.getBean(KafkaProcessor.class);
                MessageChannel outputChannel = kafkaProcessor.outboundTopic();

                outputChannel.send(MessageBuilder
                        .withPayload(json)
                        .setHeader(MessageHeaders.CONTENT_TYPE, MimeTypeUtils.APPLICATION_JSON)
                        .build()
                );
            }
        }

    }

}
