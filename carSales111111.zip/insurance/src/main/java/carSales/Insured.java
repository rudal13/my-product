package carSales;

public class Insured extends AbstractEvent {

    private Long id;
    private Long carId;
    private Integer insureAmount;

    public Insured(){
        super();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public Long getCarId() {
        return carId;
    }

    public void setCarId(Long carId) {
        this.carId = carId;
    }
    public Integer getInsureAmount() {
        return insureAmount;
    }

    public void setInsureAmount(Integer insureAmount) {
        this.insureAmount = insureAmount;
    }
}
