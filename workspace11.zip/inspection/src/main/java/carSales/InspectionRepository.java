package carSales;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface InspectionRepository extends PagingAndSortingRepository<Inspection, Long>{


}